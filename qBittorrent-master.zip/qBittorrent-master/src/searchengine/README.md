The search functionality is under internal review and is expected to undergo major refactor in the near future. \
Therefore we will only accept patches that fix major bugs. Other minor changes, refactors will be declined.
